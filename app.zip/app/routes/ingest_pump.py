# app/routes/ingest_pump.py
from fastapi import APIRouter, Header, Request, status
from app.repos.pumps import insert_pump_reading
from app.schemas.pumps import PumpPayload
from datetime import datetime, timezone

router = APIRouter(prefix="/ingest", tags=["ingest"])

@router.post("/pump", status_code=status.HTTP_201_CREATED)
def ingest_pump_route(
    payload: PumpPayload,
    request: Request,
    x_org_id: int | None = Header(default=None, convert_underscores=False),
    x_device_id: int | None = Header(default=None, convert_underscores=False),
):
    reading_id = insert_pump_reading(
        device_id=x_device_id,
        payload=payload,
        org_id=x_org_id,  # 👈 esto setea app.org_id en la conexión
    )
    # (opcional) publicar al visor si lo usás
    try:
        data = payload.model_dump(exclude_none=True)
        data.setdefault("ts", datetime.now(timezone.utc).isoformat())
        # apply_pump_ingest({...})  # si tenés el live view
    except Exception:
        pass

    src_ip = request.client.host if request and request.client else "unknown"
    return {"ok": True, "reading_id": reading_id, "source_ip": src_ip}
